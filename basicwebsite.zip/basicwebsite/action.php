<?php
session_start();
//connect to database
$conn=mysqli_connect("192.168.229.131:6033","imba","imba","databasefirewall");
if(!(isset($_SESSION['username'])))
{
  header("location:login.php");
  die();
}

if(!$conn)
{
        die('ket noi khong thanh cong'.mysqli_connect_error());
}

if(isset($_POST['query']))
{
	$query = $_POST['query'];
	if($result = mysqli_query($conn,$query))
	{
		while($row = mysqli_fetch_array($result))
		{
			echo $row['id'].'-'.$row['name'];
		}
	}
	else
	{
			echo mysqli_error($conn);
	}
	mysqli_close($conn);
}
?>
