<?php
session_start();
//connect to database
//$db=mysqli_connect("192.168.172.131","vuong","vuong","web");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Basic Website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
  <hgroup>
    <h1 class="site-title" style="text-align: center; color: green;">Basic Website</h1><br>
  </hgroup>

<br>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
  <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav center">
        <li><a href="index.php">Home</a></li>
        <li><a href="logout.php">LogOut</a></li>
      </ul>

    </div>
  </div>
</nav>
<?php
//	$db=mysqli_connect("192.168.172.131","vuong","vuong","web");
//	$username = $_SESSION['username'];	
//	$selectsql = "SELECT * FROM `users` where username = '$username'";
//	$result=mysqli_query($db,$selectsql); 
//	if($result)
//	{
//		echo "<table border='3'>
//		<tr>
//		<th>User ID</th>
//		<th>Username</th>
//		<th>Email</th>
//		<th>Password</th>
//		</tr>";
//		while($row = mysql_fetch_array($result))
//		{
//			echo "<tr>";
//			echo "<td>" . $row['userid'] . "</td>";
//			echo "<td>" . $row['username'] . "</td>";
//			echo "<td>" . $row['email']. "</td>";
//			echo "<td>" . $row['password']."</td>";
//			echo "</tr>";
//		}
//		echo "</table>";
//	}
//	else
//	{
//		$_SESSION['message']="No Information";	
//	}
//}

	$conn = new mysqli("192.168.229.131:6033","imba","imba","databasefirewall");
	if ($conn->connect_error) {
		die("Fail: " . $conn->connect_error);
	}
	$username = $_SESSION['username'];
	$sql = "SELECT * FROM users where username = '$username'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) 
	{
		while($row = $result->fetch_assoc()) {
			echo " - Userid: " . $row["userid"]. "<br>";
			echo " - Username: " . $row["username"]. "<br>";
			echo " - Mail: " . $row["email"]. "<br>";
			echo " - Address: " . $row["address"]. "<br>";
			echo " - Phone: " . $row["phone"]. "<br>";
			echo " - Password: " . $row["password"]. "<br>";
		}
	}
	else{
		echo "No Information";
	}
	$conn->close();
?>


























