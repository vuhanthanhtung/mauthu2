<?php
if(isset($_SESSION['username']))
{
  header("location:index.php");
  die();
}
?>
<head><title>REQUESTS PAGE</title>
</head>

<body>

<form action="action.php" method="POST">
<input name="query" type="text">
<input type="submit" value="query">
</form>
</body>

